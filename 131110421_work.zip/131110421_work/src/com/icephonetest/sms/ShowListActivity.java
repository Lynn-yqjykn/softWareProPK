/*
 * ���ߣ�131110421 ��������4�� ����
 * ShowListActivity�࣬������ʾѧ���б��Ļ��
 */
package com.icephonetest.sms;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;

public class ShowListActivity extends Activity {

	private ActionBar actionBar;
	private DatabaseHelper dbHelper;
	private SQLiteDatabase db;
	private Cursor cursor;
	ListAdapter listAdapter;
	private Activity mActivity;
	private ListView listview;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);
		actionBar = this.getActionBar(); // ����actionBarΪ�˱��������Ͻǵķ���
		actionBar.setDisplayHomeAsUpEnabled(true);
		dbHelper = new DatabaseHelper(this, "Info.db", null, 1); // �����ݿ�
		db = dbHelper.getWritableDatabase();
		cursor = db.query("Student", null, null, null, null, null, null);
		listAdapter = new ListAdapter(ShowListActivity.this,
				R.layout.listview_list_item, cursor, 0); // ����������
		listview = (ListView) findViewById(R.id.list_view1);
		listview.setAdapter(listAdapter); // ����������
		listview.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
				final String tempid = id + "";
				AlertDialog.Builder builder = new Builder(ShowListActivity.this);
				builder.setTitle("��ʾ");
				builder.setMessage("ȷ��Ҫɾ��������¼��");
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						String[] sArrayID = { tempid };
						db.delete("Student", "_id=?", sArrayID);
						listAdapter.notifyDataSetChanged();
					}
				});
				builder.setNegativeButton("ȡ��", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
				builder.show();
				return false;
			}
		});
	}
	// �������ϽǷ��ع���
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
		}
		return super.onOptionsItemSelected(item);
	}

	protected void onDestory() {
		super.onDestroy();
		db.close(); // ���ٻʱ�ر����ݿ�
	}
}